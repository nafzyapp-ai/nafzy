// WebAuthn utilities for biometric authentication

export function isWebAuthnSupported(): boolean {
  return !!(window.PublicKeyCredential && navigator.credentials)
}

export async function isBiometricAvailable(): Promise<boolean> {
  if (!isWebAuthnSupported()) return false

  try {
    const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
    return available
  } catch {
    return false
  }
}

// Generate a random challenge
function generateChallenge(): Uint8Array {
  const challenge = new Uint8Array(32)
  crypto.getRandomValues(challenge)
  return challenge
}

// Convert ArrayBuffer to Base64 URL
function arrayBufferToBase64Url(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer)
  let str = ""
  bytes.forEach((byte) => (str += String.fromCharCode(byte)))
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "")
}

// Convert Base64 URL to ArrayBuffer
function base64UrlToArrayBuffer(base64url: string): ArrayBuffer {
  const base64 = base64url.replace(/-/g, "+").replace(/_/g, "/")
  const padding = "=".repeat((4 - (base64.length % 4)) % 4)
  const binary = atob(base64 + padding)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i)
  }
  return bytes.buffer
}

export interface StoredCredential {
  id: string
  rawId: string
  type: string
  userEmail: string
}

const CREDENTIAL_STORAGE_KEY = "nafzy_webauthn_credentials"

export function getStoredCredentials(): StoredCredential[] {
  if (typeof window === "undefined") return []
  const stored = localStorage.getItem(CREDENTIAL_STORAGE_KEY)
  return stored ? JSON.parse(stored) : []
}

export function storeCredential(credential: StoredCredential): void {
  const credentials = getStoredCredentials()
  const existing = credentials.findIndex((c) => c.id === credential.id)
  if (existing >= 0) {
    credentials[existing] = credential
  } else {
    credentials.push(credential)
  }
  localStorage.setItem(CREDENTIAL_STORAGE_KEY, JSON.stringify(credentials))
}

export function hasStoredCredentials(): boolean {
  return getStoredCredentials().length > 0
}

export async function registerBiometric(userEmail: string): Promise<StoredCredential | null> {
  if (!isWebAuthnSupported()) {
    throw new Error("WebAuthn is not supported in this browser")
  }

  const challenge = generateChallenge()
  const userId = new TextEncoder().encode(userEmail)

  const publicKeyCredentialCreationOptions: PublicKeyCredentialCreationOptions = {
    challenge,
    rp: {
      name: "Nafzy",
      id: window.location.hostname,
    },
    user: {
      id: userId,
      name: userEmail,
      displayName: userEmail,
    },
    pubKeyCredParams: [
      { alg: -7, type: "public-key" }, // ES256
      { alg: -257, type: "public-key" }, // RS256
    ],
    authenticatorSelection: {
      authenticatorAttachment: "platform",
      userVerification: "required",
      residentKey: "preferred",
    },
    timeout: 60000,
    attestation: "none",
  }

  try {
    const credential = (await navigator.credentials.create({
      publicKey: publicKeyCredentialCreationOptions,
    })) as PublicKeyCredential

    if (!credential) return null

    const storedCredential: StoredCredential = {
      id: credential.id,
      rawId: arrayBufferToBase64Url(credential.rawId),
      type: credential.type,
      userEmail,
    }

    storeCredential(storedCredential)
    return storedCredential
  } catch (error) {
    console.error("Error registering biometric:", error)
    throw error
  }
}

export async function authenticateWithBiometric(): Promise<StoredCredential | null> {
  if (!isWebAuthnSupported()) {
    throw new Error("WebAuthn is not supported in this browser")
  }

  const storedCredentials = getStoredCredentials()
  if (storedCredentials.length === 0) {
    throw new Error("No registered biometric credentials found")
  }

  const challenge = generateChallenge()

  const publicKeyCredentialRequestOptions: PublicKeyCredentialRequestOptions = {
    challenge,
    rpId: window.location.hostname,
    allowCredentials: storedCredentials.map((cred) => ({
      id: base64UrlToArrayBuffer(cred.rawId),
      type: "public-key" as const,
      transports: ["internal"] as AuthenticatorTransport[],
    })),
    userVerification: "required",
    timeout: 60000,
  }

  try {
    const assertion = (await navigator.credentials.get({
      publicKey: publicKeyCredentialRequestOptions,
    })) as PublicKeyCredential

    if (!assertion) return null

    // Find the matching stored credential
    const matchedCredential = storedCredentials.find((cred) => cred.id === assertion.id)

    return matchedCredential || null
  } catch (error) {
    console.error("Error authenticating with biometric:", error)
    throw error
  }
}
