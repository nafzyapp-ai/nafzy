-- Seed categories with Arabic names
INSERT INTO categories (name, icon) VALUES
  ('سيارات', 'car'),
  ('عقار', 'home'),
  ('إلكترونيات', 'laptop'),
  ('هواتف', 'smartphone'),
  ('أزياء', 'shirt'),
  ('خدمات', 'wrench'),
  ('حيوانات', 'dog'),
  ('أخرى', 'package')
ON CONFLICT DO NOTHING;
