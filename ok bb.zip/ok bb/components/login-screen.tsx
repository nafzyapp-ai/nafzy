"use client"

import { ShoppingBag, Fingerprint } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function LoginScreen() {
  return (
    <div className="min-h-screen bg-[#00BCD4] flex items-center justify-center p-4">
      {/* Phone Frame */}
      <div className="relative w-full max-w-[320px]">
        {/* Phone outer frame */}
        <div className="bg-white rounded-[40px] p-3 shadow-2xl">
          {/* Phone inner screen */}
          <div className="bg-[#00BCD4] rounded-[32px] overflow-hidden">
            {/* Top section with icon */}
            <div className="pt-12 pb-8 flex justify-center">
              <div className="bg-[#FFD93D] w-16 h-16 rounded-lg flex items-center justify-center relative">
                <ShoppingBag className="w-8 h-8 text-[#00BCD4]" />
                {/* Bag handle */}
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-6 h-4 border-4 border-[#FFD93D] border-b-0 rounded-t-full bg-[#00BCD4]" />
                {/* Smiley face on bag */}
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1">
                  <div className="w-1.5 h-1.5 bg-[#00BCD4] rounded-full" />
                  <div className="w-1.5 h-1.5 bg-[#00BCD4] rounded-full" />
                </div>
                <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-1.5 border-b-2 border-[#00BCD4] rounded-b-full" />
              </div>
            </div>

            {/* White card section */}
            <div className="bg-white rounded-t-[32px] px-6 pt-8 pb-6">
              <h1 className="text-xl font-semibold text-gray-800 mb-6">Login</h1>

              {/* Input fields */}
              <div className="space-y-4 mb-8">
                <Input
                  type="text"
                  placeholder="Username"
                  className="border-0 border-b border-gray-300 rounded-none px-0 focus-visible:ring-0 focus-visible:border-[#00BCD4] bg-transparent"
                />
                <Input
                  type="password"
                  placeholder="Password"
                  className="border-0 border-b border-gray-300 rounded-none px-0 focus-visible:ring-0 focus-visible:border-[#00BCD4] bg-transparent"
                />
              </div>

              {/* Login button */}
              <Button className="w-full bg-[#00BCD4] hover:bg-[#00ACC1] text-white rounded-full py-6 text-base font-medium">
                Login
              </Button>

              {/* Fingerprint icon */}
              <div className="flex justify-center mt-8">
                <div className="w-12 h-12 rounded-full border-2 border-gray-300 flex items-center justify-center">
                  <Fingerprint className="w-6 h-6 text-gray-400" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
