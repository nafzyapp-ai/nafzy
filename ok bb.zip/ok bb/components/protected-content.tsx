"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ShoppingBag, Fingerprint, LogOut, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { isBiometricAvailable, registerBiometric, hasStoredCredentials } from "@/lib/webauthn"
import type { User } from "@supabase/supabase-js"

interface ProtectedContentProps {
  user: User
}

export function ProtectedContent({ user }: ProtectedContentProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [biometricAvailable, setBiometricAvailable] = useState(false)
  const [biometricRegistered, setBiometricRegistered] = useState(false)
  const [registeringBiometric, setRegisteringBiometric] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function checkBiometric() {
      const available = await isBiometricAvailable()
      setBiometricAvailable(available)
      setBiometricRegistered(hasStoredCredentials())
    }
    checkBiometric()
  }, [])

  const handleLogout = async () => {
    setIsLoading(true)
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/auth/login")
  }

  const handleRegisterBiometric = async () => {
    setRegisteringBiometric(true)
    setMessage(null)

    try {
      await registerBiometric(user.email || user.id)
      setBiometricRegistered(true)
      setMessage("تم تسجيل البصمة بنجاح!")
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "فشل تسجيل البصمة")
    } finally {
      setRegisteringBiometric(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#00BCD4] flex flex-col items-center justify-center p-4" dir="rtl">
      <div className="relative w-full max-w-[320px]">
        <div className="bg-white rounded-[40px] p-3 shadow-2xl">
          <div className="bg-[#00BCD4] rounded-[32px] overflow-hidden">
            {/* Top section with icon */}
            <div className="pt-12 pb-8 flex justify-center">
              <div className="bg-[#FFD93D] w-16 h-16 rounded-lg flex items-center justify-center relative">
                <ShoppingBag className="w-8 h-8 text-[#00BCD4]" />
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-6 h-4 border-4 border-[#FFD93D] border-b-0 rounded-t-full bg-[#00BCD4]" />
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1">
                  <div className="w-1.5 h-1.5 bg-[#00BCD4] rounded-full" />
                  <div className="w-1.5 h-1.5 bg-[#00BCD4] rounded-full" />
                </div>
                <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-1.5 border-b-2 border-[#00BCD4] rounded-b-full" />
              </div>
            </div>

            {/* White card section */}
            <div className="bg-white rounded-t-[32px] px-6 pt-8 pb-6">
              <h1 className="text-xl font-semibold text-gray-800 mb-2 text-center">مرحباً!</h1>
              <p className="text-gray-600 text-center mb-6 text-sm">
                {user.email || user.user_metadata?.full_name || "مستخدم"}
              </p>

              {message && (
                <p
                  className={`text-sm text-center mb-4 ${message.includes("نجاح") ? "text-green-600" : "text-red-500"}`}
                >
                  {message}
                </p>
              )}

              <div className="space-y-3">
                {biometricAvailable && !biometricRegistered && (
                  <Button
                    onClick={handleRegisterBiometric}
                    disabled={registeringBiometric}
                    className="w-full bg-white hover:bg-gray-50 text-gray-800 border border-gray-300 rounded-full py-5 text-sm font-medium flex items-center justify-center gap-2"
                  >
                    <Fingerprint className="w-4 h-4" />
                    {registeringBiometric ? "جاري التسجيل..." : "تسجيل البصمة"}
                  </Button>
                )}

                {biometricRegistered && (
                  <div className="flex items-center justify-center gap-2 text-green-600 text-sm py-2">
                    <Check className="w-4 h-4" />
                    <span>تم تسجيل البصمة</span>
                  </div>
                )}

                <Button
                  onClick={handleLogout}
                  disabled={isLoading}
                  className="w-full bg-[#00BCD4] hover:bg-[#00ACC1] text-white rounded-full py-5 text-sm font-medium flex items-center justify-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  {isLoading ? "جاري الخروج..." : "تسجيل الخروج"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Welcome text below card */}
      <div className="mt-6 text-center text-white">
        <h2 className="text-xl font-bold mb-1">مرحباً بك في Nafzy</h2>
        <p className="text-sm opacity-90 mb-4">سوق مغربي للبيع والشراء 🇲🇦</p>
        <p className="text-xs opacity-75">صنع في المغرب من طرف ABDO ELHATIMI</p>
      </div>
    </div>
  )
}
