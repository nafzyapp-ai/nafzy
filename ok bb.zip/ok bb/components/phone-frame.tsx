"use client"

import type React from "react"

import { ShoppingBag } from "lucide-react"

interface PhoneFrameProps {
  children: React.ReactNode
  showWelcome?: boolean
}

export function PhoneFrame({ children, showWelcome = true }: PhoneFrameProps) {
  return (
    <div className="min-h-screen bg-[#00BCD4] flex flex-col items-center justify-center p-4" dir="rtl">
      {/* Phone Frame */}
      <div className="relative w-full max-w-[320px]">
        {/* Phone outer frame */}
        <div className="bg-white rounded-[40px] p-3 shadow-2xl">
          {/* Phone inner screen */}
          <div className="bg-[#00BCD4] rounded-[32px] overflow-hidden">
            {/* Top section with icon */}
            <div className="pt-12 pb-8 flex justify-center">
              <div className="bg-[#FFD93D] w-16 h-16 rounded-lg flex items-center justify-center relative">
                <ShoppingBag className="w-8 h-8 text-[#00BCD4]" />
                {/* Bag handle */}
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-6 h-4 border-4 border-[#FFD93D] border-b-0 rounded-t-full bg-[#00BCD4]" />
                {/* Smiley face on bag */}
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1">
                  <div className="w-1.5 h-1.5 bg-[#00BCD4] rounded-full" />
                  <div className="w-1.5 h-1.5 bg-[#00BCD4] rounded-full" />
                </div>
                <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-1.5 border-b-2 border-[#00BCD4] rounded-b-full" />
              </div>
            </div>

            {/* White card section */}
            <div className="bg-white rounded-t-[32px] px-6 pt-8 pb-6">{children}</div>
          </div>
        </div>
      </div>

      {/* Welcome text below card */}
      {showWelcome && (
        <div className="mt-6 text-center text-white">
          <h2 className="text-xl font-bold mb-1">مرحباً بك في Nafzy</h2>
          <p className="text-sm opacity-90 mb-4">سوق مغربي للبيع والشراء 🇲🇦</p>
          <p className="text-xs opacity-75">صنع في المغرب من طرف ABDO ELHATIMI</p>
        </div>
      )}
    </div>
  )
}
