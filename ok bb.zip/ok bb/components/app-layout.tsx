"use client"

import type React from "react"
import { Home, PlusCircle, Heart, User } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"

interface AppLayoutProps {
  children: React.ReactNode
}

export function AppLayout({ children }: AppLayoutProps) {
  const pathname = usePathname()

  const navItems = [
    { href: "/home", icon: Home, label: "الرئيسية" },
    { href: "/add-listing", icon: PlusCircle, label: "إضافة" },
    { href: "/favorites", icon: Heart, label: "المفضلة" },
    { href: "/profile", icon: User, label: "حسابي" },
  ]

  return (
    <div className="min-h-screen bg-[#00BCD4] flex flex-col items-center" dir="rtl">
      {/* Phone Frame */}
      <div className="relative w-full max-w-[380px] min-h-screen">
        {/* Phone outer frame */}
        <div className="bg-white min-h-screen flex flex-col">
          {/* Main content */}
          <div className="flex-1 overflow-auto pb-20">{children}</div>

          {/* Bottom Navigation */}
          <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[380px] bg-white border-t border-gray-100 px-4 py-2 z-50">
            <div className="flex justify-around items-center">
              {navItems.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-colors ${
                      isActive ? "text-[#00BCD4]" : "text-gray-400"
                    }`}
                  >
                    <item.icon className="w-6 h-6" />
                    <span className="text-xs font-medium">{item.label}</span>
                  </Link>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
