"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { User, Mail, FileText, Heart, LogOut, ChevronLeft } from "lucide-react"
import Link from "next/link"

interface UserProfile {
  id: string
  email: string
  full_name: string
  avatar_url: string | null
}

export default function ProfilePage() {
  const [user, setUser] = useState<UserProfile | null>(null)
  const [adsCount, setAdsCount] = useState(0)
  const [favoritesCount, setFavoritesCount] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    async function fetchProfile() {
      const supabase = createClient()

      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      if (!authUser) {
        router.push("/auth/login")
        return
      }

      setUser({
        id: authUser.id,
        email: authUser.email || "",
        full_name: authUser.user_metadata?.full_name || authUser.email?.split("@")[0] || "مستخدم",
        avatar_url: authUser.user_metadata?.avatar_url || null,
      })

      // Get ads count
      const { count: adsCountResult } = await supabase
        .from("ads")
        .select("*", { count: "exact", head: true })
        .eq("user_id", authUser.id)

      setAdsCount(adsCountResult || 0)

      // Get favorites count
      const { count: favCountResult } = await supabase
        .from("favorites")
        .select("*", { count: "exact", head: true })
        .eq("user_id", authUser.id)

      setFavoritesCount(favCountResult || 0)
      setIsLoading(false)
    }
    fetchProfile()
  }, [router])

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/auth/login")
  }

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#00BCD4]" />
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      {/* Header */}
      <div className="bg-[#00BCD4] px-4 pt-6 pb-16">
        <h1 className="text-xl font-bold text-white text-center">حسابي</h1>
      </div>

      <div className="bg-white rounded-t-3xl -mt-10 px-4 pt-6 pb-8">
        {/* Profile Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6 -mt-12">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-[#00BCD4] flex items-center justify-center">
              {user?.avatar_url ? (
                <img
                  src={user.avatar_url || "/placeholder.svg"}
                  alt={user.full_name}
                  className="w-16 h-16 rounded-full object-cover"
                />
              ) : (
                <User className="w-8 h-8 text-white" />
              )}
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-800">{user?.full_name}</h2>
              <p className="text-gray-500 text-sm flex items-center gap-1">
                <Mail className="w-4 h-4" />
                {user?.email}
              </p>
            </div>
          </div>
        </div>

        {/* Menu Items */}
        <div className="space-y-3">
          <Link
            href="/my-ads"
            className="flex items-center justify-between bg-white rounded-2xl shadow-sm border border-gray-100 p-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center">
                <FileText className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <span className="font-medium text-gray-800">إعلاناتي</span>
                <p className="text-sm text-gray-400">{adsCount} إعلان</p>
              </div>
            </div>
            <ChevronLeft className="w-5 h-5 text-gray-400" />
          </Link>

          <Link
            href="/favorites"
            className="flex items-center justify-between bg-white rounded-2xl shadow-sm border border-gray-100 p-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center">
                <Heart className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <span className="font-medium text-gray-800">المفضلة</span>
                <p className="text-sm text-gray-400">{favoritesCount} إعلان</p>
              </div>
            </div>
            <ChevronLeft className="w-5 h-5 text-gray-400" />
          </Link>
        </div>

        {/* Logout Button */}
        <Button
          onClick={handleLogout}
          className="w-full mt-8 bg-red-50 hover:bg-red-100 text-red-500 rounded-full py-6 text-base font-medium flex items-center justify-center gap-2"
        >
          <LogOut className="w-5 h-5" />
          تسجيل الخروج
        </Button>
      </div>
    </AppLayout>
  )
}
