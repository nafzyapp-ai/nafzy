"use client"

import { useState, useEffect, use } from "react"
import { AppLayout } from "@/components/app-layout"
import { createClient } from "@/lib/supabase/client"
import { ArrowRight, ShoppingBag } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface Ad {
  id: string
  title: string
  price: number
  city: string
  images: string[]
}

const categoryNames: Record<string, string> = {
  cars: "سيارات",
  realestate: "عقار",
  electronics: "إلكترونيات",
  phones: "هواتف",
  fashion: "أزياء",
  services: "خدمات",
  animals: "حيوانات",
  other: "أخرى",
}

export default function CategoryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const [ads, setAds] = useState<Ad[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    async function fetchCategoryAds() {
      const supabase = createClient()

      const { data, error } = await supabase
        .from("ads")
        .select("id, title, price, city, images")
        .eq("category", id)
        .eq("status", "active")
        .order("created_at", { ascending: false })

      if (!error && data) {
        setAds(data)
      }
      setIsLoading(false)
    }
    fetchCategoryAds()
  }, [id])

  return (
    <AppLayout>
      {/* Header */}
      <div className="bg-[#00BCD4] px-4 pt-4 pb-8">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="text-white">
            <ArrowRight className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold text-white">{categoryNames[id] || id}</h1>
        </div>
      </div>

      <div className="bg-white rounded-t-3xl -mt-4 px-4 pt-6 pb-8 min-h-[60vh]">
        {isLoading ? (
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-gray-100 rounded-2xl h-48 animate-pulse" />
            ))}
          </div>
        ) : ads.length > 0 ? (
          <div className="grid grid-cols-2 gap-4">
            {ads.map((ad) => (
              <Link
                key={ad.id}
                href={`/ad/${ad.id}`}
                className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100"
              >
                <div className="relative h-28 bg-gray-100">
                  {ad.images && ad.images[0] ? (
                    <Image src={ad.images[0] || "/placeholder.svg"} alt={ad.title} fill className="object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <ShoppingBag className="w-8 h-8 text-gray-300" />
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="text-sm font-medium text-gray-800 truncate">{ad.title}</h3>
                  <p className="text-[#00BCD4] font-bold text-sm mt-1">{ad.price} درهم</p>
                  <p className="text-xs text-gray-400 mt-1">{ad.city}</p>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <ShoppingBag className="w-16 h-16 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-400">لا توجد إعلانات في هذه الفئة</p>
            <Link href="/home" className="inline-block mt-4 text-[#00BCD4]">
              العودة للرئيسية
            </Link>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
