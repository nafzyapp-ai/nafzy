"use client"

import { useState, useEffect, use } from "react"
import { useRouter } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { ArrowRight, Heart, Share2, MapPin, Calendar, Tag, ShoppingBag } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

interface Ad {
  id: string
  title: string
  description: string
  price: number
  city: string
  category: string
  condition: string
  whatsapp: string
  images: string[]
  created_at: string
  user_id: string
}

const categoryNames: Record<string, string> = {
  cars: "سيارات",
  realestate: "عقار",
  electronics: "إلكترونيات",
  phones: "هواتف",
  fashion: "أزياء",
  services: "خدمات",
  animals: "حيوانات",
  other: "أخرى",
}

export default function AdDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const [ad, setAd] = useState<Ad | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isFavorite, setIsFavorite] = useState(false)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [userId, setUserId] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function fetchAd() {
      const supabase = createClient()

      // Get current user
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (user) {
        setUserId(user.id)

        // Check if ad is in favorites
        const { data: favorite } = await supabase
          .from("favorites")
          .select("id")
          .eq("user_id", user.id)
          .eq("ad_id", id)
          .single()

        setIsFavorite(!!favorite)
      }

      // Fetch ad details
      const { data, error } = await supabase.from("ads").select("*").eq("id", id).single()

      if (!error && data) {
        setAd(data)
      }
      setIsLoading(false)
    }
    fetchAd()
  }, [id])

  const toggleFavorite = async () => {
    if (!userId) {
      router.push("/auth/login")
      return
    }

    const supabase = createClient()

    if (isFavorite) {
      await supabase.from("favorites").delete().eq("user_id", userId).eq("ad_id", id)
    } else {
      await supabase.from("favorites").insert({ user_id: userId, ad_id: id })
    }

    setIsFavorite(!isFavorite)
  }

  const handleWhatsAppContact = () => {
    if (ad?.whatsapp) {
      window.open(`https://wa.me/${ad.whatsapp}`, "_blank")
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("ar-MA", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#00BCD4]" />
        </div>
      </AppLayout>
    )
  }

  if (!ad) {
    return (
      <AppLayout>
        <div className="text-center py-12">
          <ShoppingBag className="w-16 h-16 text-gray-200 mx-auto mb-4" />
          <p className="text-gray-400">الإعلان غير موجود</p>
          <Link href="/home" className="inline-block mt-4 text-[#00BCD4]">
            العودة للرئيسية
          </Link>
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      {/* Header */}
      <div className="bg-[#00BCD4] px-4 pt-4 pb-6">
        <div className="flex items-center justify-between">
          <button onClick={() => router.back()} className="text-white">
            <ArrowRight className="w-6 h-6" />
          </button>
          <h1 className="text-lg font-bold text-white">تفاصيل الإعلان</h1>
          <div className="flex gap-2">
            <button
              onClick={toggleFavorite}
              className={`p-2 rounded-full ${isFavorite ? "bg-red-500" : "bg-white/20"}`}
            >
              <Heart className={`w-5 h-5 ${isFavorite ? "text-white fill-white" : "text-white"}`} />
            </button>
            <button className="bg-white/20 p-2 rounded-full">
              <Share2 className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-t-3xl -mt-4">
        {/* Image Gallery */}
        {ad.images && ad.images.length > 0 ? (
          <div className="relative">
            <div className="relative h-64">
              <Image
                src={ad.images[currentImageIndex] || "/placeholder.svg"}
                alt={ad.title}
                fill
                className="object-cover rounded-t-3xl"
              />
            </div>
            {ad.images.length > 1 && (
              <div className="flex justify-center gap-2 py-3">
                {ad.images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-2 h-2 rounded-full ${index === currentImageIndex ? "bg-[#00BCD4]" : "bg-gray-300"}`}
                  />
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="h-48 bg-gray-100 rounded-t-3xl flex items-center justify-center">
            <ShoppingBag className="w-16 h-16 text-gray-300" />
          </div>
        )}

        {/* Content */}
        <div className="px-4 py-6">
          {/* Title & Price */}
          <div className="mb-4">
            <h2 className="text-xl font-bold text-gray-800 mb-2">{ad.title}</h2>
            <p className="text-2xl font-bold text-[#00BCD4]">{ad.price} درهم</p>
          </div>

          {/* Meta Info */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex items-center gap-1 text-gray-500 text-sm">
              <MapPin className="w-4 h-4" />
              <span>{ad.city}</span>
            </div>
            <div className="flex items-center gap-1 text-gray-500 text-sm">
              <Tag className="w-4 h-4" />
              <span>{categoryNames[ad.category] || ad.category}</span>
            </div>
            <div className="flex items-center gap-1 text-gray-500 text-sm">
              <Calendar className="w-4 h-4" />
              <span>{formatDate(ad.created_at)}</span>
            </div>
          </div>

          {/* Condition Badge */}
          <div className="mb-6">
            <span
              className={`inline-block px-4 py-1 rounded-full text-sm font-medium ${
                ad.condition === "new" ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"
              }`}
            >
              {ad.condition === "new" ? "جديد" : "مستعمل"}
            </span>
          </div>

          {/* Description */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">الوصف</h3>
            <p className="text-gray-600 leading-relaxed">{ad.description}</p>
          </div>

          {/* WhatsApp Button */}
          <Button
            onClick={handleWhatsAppContact}
            className="w-full bg-[#25D366] hover:bg-[#20BD5A] text-white rounded-full py-6 text-base font-medium flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            تواصل عبر واتساب
          </Button>
        </div>
      </div>
    </AppLayout>
  )
}
