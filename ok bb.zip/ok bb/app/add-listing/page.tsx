"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { createClient } from "@/lib/supabase/client"
import { Camera, X, ChevronDown } from "lucide-react"
import Image from "next/image"

const categories = [
  { id: "cars", name: "سيارات" },
  { id: "realestate", name: "عقار" },
  { id: "electronics", name: "إلكترونيات" },
  { id: "phones", name: "هواتف" },
  { id: "fashion", name: "أزياء" },
  { id: "services", name: "خدمات" },
  { id: "animals", name: "حيوانات" },
  { id: "other", name: "أخرى" },
]

const cities = ["الدار البيضاء", "الرباط", "فاس", "مراكش", "طنجة", "أكادير", "مكناس", "وجدة", "القنيطرة", "تطوان"]

export default function AddListingPage() {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [price, setPrice] = useState("")
  const [city, setCity] = useState("")
  const [category, setCategory] = useState("")
  const [condition, setCondition] = useState<"new" | "used">("new")
  const [whatsapp, setWhatsapp] = useState("")
  const [images, setImages] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [userId, setUserId] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function checkAuth() {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        router.push("/auth/login")
      } else {
        setUserId(user.id)
      }
    }
    checkAuth()
  }, [router])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    if (images.length + files.length > 3) {
      setError("يمكنك رفع 3 صور كحد أقصى")
      return
    }

    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImages((prev) => [...prev, reader.result as string])
      }
      reader.readAsDataURL(file)
    })
  }

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleWhatsappChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "")
    setWhatsapp(value)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    if (!userId) {
      setError("يرجى تسجيل الدخول أولاً")
      setIsLoading(false)
      return
    }

    try {
      const supabase = createClient()

      const { error: insertError } = await supabase.from("ads").insert({
        user_id: userId,
        title,
        description,
        price: Number.parseFloat(price),
        city,
        category,
        condition,
        whatsapp,
        images,
        status: "active",
      })

      if (insertError) throw insertError
      router.push("/my-ads")
    } catch (err) {
      setError(err instanceof Error ? err.message : "حدث خطأ أثناء نشر الإعلان")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AppLayout>
      <div className="bg-[#00BCD4] px-4 pt-6 pb-8">
        <h1 className="text-xl font-bold text-white text-center">إضافة إعلان</h1>
      </div>

      <div className="bg-white rounded-t-3xl -mt-4 px-4 pt-6 pb-8">
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Images */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">الصور (3 صور كحد أقصى)</label>
            <div className="flex gap-3">
              {images.map((img, index) => (
                <div key={index} className="relative w-20 h-20 rounded-xl overflow-hidden">
                  <Image src={img || "/placeholder.svg"} alt={`صورة ${index + 1}`} fill className="object-cover" />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {images.length < 3 && (
                <label className="w-20 h-20 border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-[#00BCD4] transition-colors">
                  <Camera className="w-6 h-6 text-gray-400" />
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" multiple />
                </label>
              )}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">عنوان الإعلان</label>
            <Input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="border border-gray-200 rounded-xl px-4 py-3 focus-visible:ring-[#00BCD4] text-right"
              placeholder="مثال: هاتف آيفون 15 برو"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">الوصف</label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              className="border border-gray-200 rounded-xl px-4 py-3 focus-visible:ring-[#00BCD4] text-right min-h-[100px]"
              placeholder="اكتب وصفاً تفصيلياً للسلعة..."
            />
          </div>

          {/* Price */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">الثمن (درهم)</label>
            <Input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              required
              className="border border-gray-200 rounded-xl px-4 py-3 focus-visible:ring-[#00BCD4] text-right"
              placeholder="0"
            />
          </div>

          {/* City */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">المدينة</label>
            <div className="relative">
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                required
                className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:ring-[#00BCD4] focus:border-[#00BCD4] text-right appearance-none bg-white"
              >
                <option value="">اختر المدينة</option>
                {cities.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">الفئة</label>
            <div className="relative">
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                required
                className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:ring-[#00BCD4] focus:border-[#00BCD4] text-right appearance-none bg-white"
              >
                <option value="">اختر الفئة</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
            </div>
          </div>

          {/* Condition */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">الحالة</label>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setCondition("new")}
                className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                  condition === "new" ? "bg-[#00BCD4] text-white" : "bg-gray-100 text-gray-600"
                }`}
              >
                جديد
              </button>
              <button
                type="button"
                onClick={() => setCondition("used")}
                className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                  condition === "used" ? "bg-[#00BCD4] text-white" : "bg-gray-100 text-gray-600"
                }`}
              >
                مستعمل
              </button>
            </div>
          </div>

          {/* WhatsApp */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">رقم الواتساب</label>
            <Input
              type="tel"
              value={whatsapp}
              onChange={handleWhatsappChange}
              required
              className="border border-gray-200 rounded-xl px-4 py-3 focus-visible:ring-[#00BCD4] text-right"
              placeholder="06XXXXXXXX"
            />
          </div>

          {error && <p className="text-sm text-red-500 text-center">{error}</p>}

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-[#00BCD4] hover:bg-[#00ACC1] text-white rounded-full py-6 text-base font-medium"
          >
            {isLoading ? "جاري النشر..." : "نشر الإعلان"}
          </Button>
        </form>
      </div>
    </AppLayout>
  )
}
