"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import { createClient } from "@/lib/supabase/client"
import { Heart, ShoppingBag } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

interface Ad {
  id: string
  title: string
  price: number
  city: string
  images: string[]
}

interface Favorite {
  id: string
  ad_id: string
  ads: Ad
}

export default function FavoritesPage() {
  const [favorites, setFavorites] = useState<Favorite[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    async function fetchFavorites() {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data, error } = await supabase
        .from("favorites")
        .select(`
          id,
          ad_id,
          ads (
            id,
            title,
            price,
            city,
            images
          )
        `)
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })

      if (!error && data) {
        setFavorites(data as unknown as Favorite[])
      }
      setIsLoading(false)
    }
    fetchFavorites()
  }, [router])

  const removeFavorite = async (favoriteId: string) => {
    const supabase = createClient()
    await supabase.from("favorites").delete().eq("id", favoriteId)
    setFavorites((prev) => prev.filter((f) => f.id !== favoriteId))
  }

  return (
    <AppLayout>
      {/* Header */}
      <div className="bg-[#00BCD4] px-4 pt-6 pb-8">
        <h1 className="text-xl font-bold text-white text-center">المفضلة</h1>
      </div>

      <div className="bg-white rounded-t-3xl -mt-4 px-4 pt-6 pb-8 min-h-[60vh]">
        {isLoading ? (
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-gray-100 rounded-2xl h-48 animate-pulse" />
            ))}
          </div>
        ) : favorites.length > 0 ? (
          <div className="grid grid-cols-2 gap-4">
            {favorites.map((favorite) => (
              <div
                key={favorite.id}
                className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 relative"
              >
                <button
                  onClick={() => removeFavorite(favorite.id)}
                  className="absolute top-2 left-2 z-10 bg-red-500 p-1.5 rounded-full"
                >
                  <Heart className="w-4 h-4 text-white fill-white" />
                </button>
                <Link href={`/ad/${favorite.ads.id}`}>
                  <div className="relative h-28 bg-gray-100">
                    {favorite.ads.images && favorite.ads.images[0] ? (
                      <Image
                        src={favorite.ads.images[0] || "/placeholder.svg"}
                        alt={favorite.ads.title}
                        fill
                        className="object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ShoppingBag className="w-8 h-8 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <h3 className="text-sm font-medium text-gray-800 truncate">{favorite.ads.title}</h3>
                    <p className="text-[#00BCD4] font-bold text-sm mt-1">{favorite.ads.price} درهم</p>
                    <p className="text-xs text-gray-400 mt-1">{favorite.ads.city}</p>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Heart className="w-16 h-16 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-400 mb-2">لا توجد إعلانات في المفضلة</p>
            <Link href="/home" className="text-[#00BCD4] text-sm">
              تصفح الإعلانات
            </Link>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
