"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { Edit, Trash2, ShoppingBag, Plus } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

interface Ad {
  id: string
  title: string
  price: number
  city: string
  images: string[]
  status: string
  created_at: string
}

export default function MyAdsPage() {
  const [ads, setAds] = useState<Ad[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function fetchMyAds() {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data, error } = await supabase
        .from("ads")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })

      if (!error && data) {
        setAds(data)
      }
      setIsLoading(false)
    }
    fetchMyAds()
  }, [router])

  const deleteAd = async (adId: string) => {
    setDeletingId(adId)
    const supabase = createClient()

    const { error } = await supabase.from("ads").delete().eq("id", adId)

    if (!error) {
      setAds((prev) => prev.filter((ad) => ad.id !== adId))
    }
    setDeletingId(null)
  }

  return (
    <AppLayout>
      {/* Header */}
      <div className="bg-[#00BCD4] px-4 pt-6 pb-8">
        <h1 className="text-xl font-bold text-white text-center">إعلاناتي</h1>
      </div>

      <div className="bg-white rounded-t-3xl -mt-4 px-4 pt-6 pb-8 min-h-[60vh]">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-gray-100 rounded-2xl h-24 animate-pulse" />
            ))}
          </div>
        ) : ads.length > 0 ? (
          <div className="space-y-4">
            {ads.map((ad) => (
              <div key={ad.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 flex">
                <Link href={`/ad/${ad.id}`} className="flex-1 flex">
                  <div className="relative w-24 h-24 bg-gray-100 flex-shrink-0">
                    {ad.images && ad.images[0] ? (
                      <Image src={ad.images[0] || "/placeholder.svg"} alt={ad.title} fill className="object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ShoppingBag className="w-6 h-6 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 p-3">
                    <h3 className="text-sm font-medium text-gray-800 truncate">{ad.title}</h3>
                    <p className="text-[#00BCD4] font-bold text-sm mt-1">{ad.price} درهم</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-gray-400">{ad.city}</span>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full ${
                          ad.status === "active" ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-500"
                        }`}
                      >
                        {ad.status === "active" ? "نشط" : "غير نشط"}
                      </span>
                    </div>
                  </div>
                </Link>
                <div className="flex flex-col justify-center gap-2 p-2">
                  <Link
                    href={`/edit-ad/${ad.id}`}
                    className="p-2 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                  >
                    <Edit className="w-4 h-4 text-blue-500" />
                  </Link>
                  <button
                    onClick={() => deleteAd(ad.id)}
                    disabled={deletingId === ad.id}
                    className="p-2 bg-red-50 rounded-lg hover:bg-red-100 transition-colors disabled:opacity-50"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <ShoppingBag className="w-16 h-16 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-400 mb-4">لم تنشر أي إعلان بعد</p>
            <Link href="/add-listing">
              <Button className="bg-[#00BCD4] hover:bg-[#00ACC1] text-white rounded-full px-6 py-3 flex items-center gap-2 mx-auto">
                <Plus className="w-5 h-5" />
                أضف إعلانك الأول
              </Button>
            </Link>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
