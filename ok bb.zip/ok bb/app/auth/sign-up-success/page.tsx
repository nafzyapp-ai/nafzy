"use client"

import { Button } from "@/components/ui/button"
import { PhoneFrame } from "@/components/phone-frame"
import Link from "next/link"

export default function SignUpSuccessPage() {
  return (
    <PhoneFrame>
      <h1 className="text-xl font-semibold text-gray-800 mb-4 text-center">شكراً لتسجيلك!</h1>
      <p className="text-gray-600 text-center mb-6 text-sm">
        تم إنشاء حسابك بنجاح. يرجى التحقق من بريدك الإلكتروني لتأكيد حسابك قبل تسجيل الدخول.
      </p>
      <Link href="/auth/login">
        <Button className="w-full bg-[#00BCD4] hover:bg-[#00ACC1] text-white rounded-full py-6 text-base font-medium">
          العودة لتسجيل الدخول
        </Button>
      </Link>
    </PhoneFrame>
  )
}
