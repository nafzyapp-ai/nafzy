"use client"

import { Button } from "@/components/ui/button"
import { PhoneFrame } from "@/components/phone-frame"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Suspense } from "react"

function ErrorContent() {
  const searchParams = useSearchParams()
  const error = searchParams.get("error")

  return (
    <PhoneFrame>
      <h1 className="text-xl font-semibold text-gray-800 mb-4 text-center">حدث خطأ</h1>
      <p className="text-gray-600 text-center mb-2 text-sm">عذراً، حدث خطأ أثناء المعالجة.</p>
      {error && <p className="text-red-500 text-center mb-6 text-xs">رمز الخطأ: {error}</p>}
      <Link href="/auth/login">
        <Button className="w-full bg-[#00BCD4] hover:bg-[#00ACC1] text-white rounded-full py-6 text-base font-medium">
          العودة لتسجيل الدخول
        </Button>
      </Link>
    </PhoneFrame>
  )
}

export default function ErrorPage() {
  return (
    <Suspense
      fallback={
        <PhoneFrame>
          <h1 className="text-xl font-semibold text-gray-800 mb-4 text-center">جاري التحميل...</h1>
        </PhoneFrame>
      }
    >
      <ErrorContent />
    </Suspense>
  )
}
