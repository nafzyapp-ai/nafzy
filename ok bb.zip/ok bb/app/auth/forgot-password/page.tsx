"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { PhoneFrame } from "@/components/phone-frame"
import { createClient } from "@/lib/supabase/client"
import Link from "next/link"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo:
          process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/auth/reset-password`,
      })

      if (error) throw error
      setSuccess(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : "حدث خطأ أثناء إرسال رابط الاستعادة")
    } finally {
      setIsLoading(false)
    }
  }

  if (success) {
    return (
      <PhoneFrame>
        <h1 className="text-xl font-semibold text-gray-800 mb-4 text-center">تم الإرسال!</h1>
        <p className="text-gray-600 text-center mb-6 text-sm">
          تم إرسال رابط استعادة كلمة المرور إلى بريدك الإلكتروني. يرجى التحقق من صندوق الوارد.
        </p>
        <Link href="/auth/login">
          <Button className="w-full bg-[#00BCD4] hover:bg-[#00ACC1] text-white rounded-full py-6 text-base font-medium">
            العودة لتسجيل الدخول
          </Button>
        </Link>
      </PhoneFrame>
    )
  }

  return (
    <PhoneFrame>
      <h1 className="text-xl font-semibold text-gray-800 mb-2 text-center">نسيت كلمة المرور؟</h1>
      <p className="text-gray-500 text-center mb-6 text-sm">
        أدخل بريدك الإلكتروني وسنرسل لك رابط لاستعادة كلمة المرور
      </p>

      <form onSubmit={handleResetPassword} className="space-y-4 mb-6">
        <Input
          type="email"
          placeholder="البريد الإلكتروني"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="border-0 border-b border-gray-300 rounded-none px-0 focus-visible:ring-0 focus-visible:border-[#00BCD4] bg-transparent text-right"
        />

        {error && <p className="text-sm text-red-500 text-center">{error}</p>}

        <Button
          type="submit"
          disabled={isLoading}
          className="w-full bg-[#00BCD4] hover:bg-[#00ACC1] text-white rounded-full py-6 text-base font-medium"
        >
          {isLoading ? "جاري الإرسال..." : "إرسال رابط الاستعادة"}
        </Button>
      </form>

      <div className="text-center text-sm">
        <Link href="/auth/login" className="text-[#00BCD4] hover:underline">
          العودة لتسجيل الدخول
        </Link>
      </div>
    </PhoneFrame>
  )
}
