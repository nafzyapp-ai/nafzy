"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { PhoneFrame } from "@/components/phone-frame"
import { createClient } from "@/lib/supabase/client"

export default function ResetPasswordPage() {
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Handle the hash fragment from email link
    const hashParams = new URLSearchParams(window.location.hash.substring(1))
    const accessToken = hashParams.get("access_token")
    const refreshToken = hashParams.get("refresh_token")

    if (accessToken && refreshToken) {
      const supabase = createClient()
      supabase.auth.setSession({
        access_token: accessToken,
        refresh_token: refreshToken,
      })
    }
  }, [])

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    if (password !== confirmPassword) {
      setError("كلمات المرور غير متطابقة")
      setIsLoading(false)
      return
    }

    if (password.length < 6) {
      setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل")
      setIsLoading(false)
      return
    }

    try {
      const supabase = createClient()
      const { error } = await supabase.auth.updateUser({
        password: password,
      })

      if (error) throw error
      router.push("/auth/login")
    } catch (err) {
      setError(err instanceof Error ? err.message : "حدث خطأ أثناء تحديث كلمة المرور")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <PhoneFrame>
      <h1 className="text-xl font-semibold text-gray-800 mb-2 text-center">كلمة مرور جديدة</h1>
      <p className="text-gray-500 text-center mb-6 text-sm">أدخل كلمة المرور الجديدة</p>

      <form onSubmit={handleUpdatePassword} className="space-y-4 mb-6">
        <Input
          type="password"
          placeholder="كلمة المرور الجديدة"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="border-0 border-b border-gray-300 rounded-none px-0 focus-visible:ring-0 focus-visible:border-[#00BCD4] bg-transparent text-right"
        />
        <Input
          type="password"
          placeholder="تأكيد كلمة المرور"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
          className="border-0 border-b border-gray-300 rounded-none px-0 focus-visible:ring-0 focus-visible:border-[#00BCD4] bg-transparent text-right"
        />

        {error && <p className="text-sm text-red-500 text-center">{error}</p>}

        <Button
          type="submit"
          disabled={isLoading}
          className="w-full bg-[#00BCD4] hover:bg-[#00ACC1] text-white rounded-full py-6 text-base font-medium"
        >
          {isLoading ? "جاري التحديث..." : "تحديث كلمة المرور"}
        </Button>
      </form>
    </PhoneFrame>
  )
}
