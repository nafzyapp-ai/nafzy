"use client"

import { useState, useEffect } from "react"
import { AppLayout } from "@/components/app-layout"
import {
  Bell,
  Search,
  SlidersHorizontal,
  Car,
  Building,
  Smartphone,
  Shirt,
  Wrench,
  Dog,
  MoreHorizontal,
  Cpu,
  ShoppingBag,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { createClient } from "@/lib/supabase/client"
import Link from "next/link"
import Image from "next/image"

interface Ad {
  id: string
  title: string
  price: number
  city: string
  images: string[]
  created_at: string
}

const categories = [
  { id: "cars", name: "سيارات", icon: Car, color: "#FF6B6B" },
  { id: "realestate", name: "عقار", icon: Building, color: "#4ECDC4" },
  { id: "electronics", name: "إلكترونيات", icon: Cpu, color: "#45B7D1" },
  { id: "phones", name: "هواتف", icon: Smartphone, color: "#96CEB4" },
  { id: "fashion", name: "أزياء", icon: Shirt, color: "#FFEAA7" },
  { id: "services", name: "خدمات", icon: Wrench, color: "#DDA0DD" },
  { id: "animals", name: "حيوانات", icon: Dog, color: "#98D8C8" },
  { id: "other", name: "أخرى", icon: MoreHorizontal, color: "#F7DC6F" },
]

export default function HomePage() {
  const [ads, setAds] = useState<Ad[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchAds() {
      const supabase = createClient()
      const { data, error } = await supabase
        .from("ads")
        .select("*")
        .eq("status", "active")
        .order("created_at", { ascending: false })
        .limit(20)

      if (!error && data) {
        setAds(data)
      }
      setIsLoading(false)
    }
    fetchAds()
  }, [])

  const filteredAds = ads.filter((ad) => ad.title.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <AppLayout>
      {/* Header */}
      <div className="bg-[#00BCD4] px-4 pt-6 pb-8">
        <div className="flex items-center justify-between mb-6">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="bg-[#FFD93D] w-10 h-10 rounded-lg flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 text-[#00BCD4]" />
            </div>
            <span className="text-white font-bold text-xl">Nafzy</span>
          </div>
          {/* Notifications */}
          <button className="bg-white/20 p-2 rounded-full">
            <Bell className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="ابحث عن سلعة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-3 rounded-full bg-white border-0 text-right"
            />
          </div>
          <button className="bg-white p-3 rounded-full">
            <SlidersHorizontal className="w-5 h-5 text-[#00BCD4]" />
          </button>
        </div>
      </div>

      {/* Categories */}
      <div className="bg-white rounded-t-3xl -mt-4 px-4 pt-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">الفئات</h2>
        <div className="grid grid-cols-4 gap-4 mb-6">
          {categories.map((category) => (
            <Link key={category.id} href={`/category/${category.id}`} className="flex flex-col items-center gap-2">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: `${category.color}20` }}
              >
                <category.icon className="w-6 h-6" style={{ color: category.color }} />
              </div>
              <span className="text-xs text-gray-600 text-center">{category.name}</span>
            </Link>
          ))}
        </div>

        {/* Latest Ads */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-800">أحدث الإعلانات</h2>
            <Link href="/ads" className="text-[#00BCD4] text-sm">
              عرض الكل
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="bg-gray-100 rounded-2xl h-48 animate-pulse" />
              ))}
            </div>
          ) : filteredAds.length > 0 ? (
            <div className="grid grid-cols-2 gap-4">
              {filteredAds.map((ad) => (
                <Link
                  key={ad.id}
                  href={`/ad/${ad.id}`}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100"
                >
                  <div className="relative h-28 bg-gray-100">
                    {ad.images && ad.images[0] ? (
                      <Image src={ad.images[0] || "/placeholder.svg"} alt={ad.title} fill className="object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ShoppingBag className="w-8 h-8 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <h3 className="text-sm font-medium text-gray-800 truncate">{ad.title}</h3>
                    <p className="text-[#00BCD4] font-bold text-sm mt-1">{ad.price} درهم</p>
                    <p className="text-xs text-gray-400 mt-1">{ad.city}</p>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <ShoppingBag className="w-16 h-16 text-gray-200 mx-auto mb-4" />
              <p className="text-gray-400">لا توجد إعلانات حالياً</p>
              <Link
                href="/add-listing"
                className="inline-block mt-4 bg-[#00BCD4] text-white px-6 py-2 rounded-full text-sm"
              >
                أضف أول إعلان
              </Link>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  )
}
